package sit.int221.sas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SasBackEndApplicationTests {

    @Test
    void contextLoads() {
    }

}
