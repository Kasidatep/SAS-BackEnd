package sit.int221.sas.utils;

public enum AnnouncementDisplayEnum {
    Y,N
}
