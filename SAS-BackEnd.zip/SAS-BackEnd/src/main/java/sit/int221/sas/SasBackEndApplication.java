package sit.int221.sas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SasBackEndApplication {

    public static void main(String[] args) {SpringApplication.run(SasBackEndApplication.class, args);
    }
}

